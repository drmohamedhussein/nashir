=== Nashir ===
Contributors: nashir
Tags: editorial calendar, schedule, publish, wordpress, social
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

تقويم ناشر: جدولة ونشر وإعادة نشر ومشاركة اجتماعية من ووردبريس أو من حساب ناشر.

== Description ==

Nashir is an original WordPress connector for the Nashir cloud account. Sign in with your Nashir email and password. The license activates only when the site has an active per-site subscription. Calendar, missed schedules, unpublish/republish, advanced updates, and social templates work from wp-admin and stay in sync with the cloud.

== Installation ==

1. Upload the `nashir` folder to `/wp-content/plugins/`
2. Activate the plugin
3. Open Nashir in wp-admin and sign in with your Nashir account

== Changelog ==

= 1.1.0 =
* Account login license, calendar, missed schedule, unpublish/republish, advanced editors, social templates.

= 1.0.0 =
* First public release: pairing, signed REST, calendar sync, cloud publish, heartbeat.
